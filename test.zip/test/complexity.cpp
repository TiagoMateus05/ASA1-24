#include <iostream>
#include <cmath>

int calculateComplexity(int n, int m) {
    //put the complexity funcion
    return n*n*n*m*m;
}

int main() {
    int n;
    int m;
    std::cin >> n; 
    std::cin >> m;
    std::cout << "Complexity Value: O(" << calculateComplexity(n,m) << ")" << std::endl;
}